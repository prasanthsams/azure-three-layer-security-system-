Microsoft Azure CLI 'init' Extension
==========================================

This package is for the 'init' extension.
i.e. 'az init'

.. :changelog:

Release History
===============

0.1.0
++++++
* Initial release.

